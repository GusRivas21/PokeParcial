<script setup>
    import { ref, computed } from 'vue';
    import axios from 'axios'

    // ...existing code...

    // Agregar nuevo estado para los pokemon por tipo
    const pokemonsPorTipo = ref([])
    const tipoSeleccionado = ref('')
    const cargandoTipo = ref(false)

    const pokemonSeleccionado = ref(null)

    const mostrarDetalles = (poke) => {
    pokemonSeleccionado.value = poke
    }

    const cerrarDetalles = () => {
    pokemonSeleccionado.value = null
    }

    // Función para buscar pokemon por tipo
    const buscarPorTipo = async (tipo) => {
    try {
        cargandoTipo.value = true
        tipoSeleccionado.value = tipo
        const response = await axios.get(`https://pokeapi.co/api/v2/type/${tipo}`)
        // Obtener solo los primeros 5 pokemon del tipo
        const primerosCincoPokemon = response.data.pokemon.slice(0, 5)

        // Obtener detalles de cada pokemon
        const detallesPokemon = await Promise.all(
        primerosCincoPokemon.map(async (p) => {
            const res = await axios.get(p.pokemon.url)
            return res.data
        })
        )

        pokemonsPorTipo.value = detallesPokemon
    } catch (e) {
        error.value = "Error al buscar pokemon por tipo"
    } finally {
        cargandoTipo.value = false
    }
    }

    // Lista de tipos principales de Pokemon
    const tiposPrincipales = [
    'fire', 'water', 'grass', 'electric', 'psychic',
    'rock', 'ground', 'ice', 'flying', 'ghost'
    ]
</script>

<template>
    <div>
        <div class="mt-4 mb-4">
        <h3 class="text-lg font-bold mb-2">Buscar por tipo:</h3>
        <div class="flex flex-wrap gap-2">
            <button
            v-for="tipo in tiposPrincipales"
            :key="tipo"
            @click="buscarPorTipo(tipo)"
            :class="`px-3 py-1 rounded-full text-white capitalize
                ${tipoSeleccionado === tipo ? 'ring-2 ring-offset-2' : ''}
                ${tipo === 'fire' ? 'bg-red-500' :
                tipo === 'water' ? 'bg-blue-500' :
                tipo === 'grass' ? 'bg-green-500' :
                tipo === 'electric' ? 'bg-yellow-500' :
                tipo === 'psychic' ? 'bg-pink-500' :
                tipo === 'rock' ? 'bg-gray-500' :
                tipo === 'ground' ? 'bg-yellow-700' :
                tipo === 'ice' ? 'bg-blue-300' :
                tipo === 'flying' ? 'bg-indigo-400' :
                'bg-purple-500'}`"
            >
            {{ tipo }}
            </button>
        </div>
        </div>

        <!-- Resultados de la búsqueda por tipo -->
        <div v-if="pokemonsPorTipo.length > 0" class="resultados-horizontal">
        <div
            v-for="poke in pokemonsPorTipo"
            :key="poke.id"
            @click="mostrarDetalles(poke)"
            class="tarjeta-pokemon"
        >
            <img :src="poke.sprites.front_default" :alt="poke.name" class="mx-auto">
            <h3 class="font-bold capitalize">{{ poke.name }}</h3>
        </div>
        </div>

    <div v-if="pokemonSeleccionado" :class="resultado_pokemon"
            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div class="bg-white p-6 rounded-lg max-w-sm w-full mx-4">
            <div class="text-right">
            <button @click="cerrarDetalles"
                    class="text-gray-500 hover:text-gray-700">
                ✕
            </button>
            </div>
            <img :src="pokemonSeleccionado.sprites.front_default"
                :alt="pokemonSeleccionado.name"
                class="mx-auto w-32">
            <h2 class="text-2xl font-bold capitalize text-center mb-4">
            {{ pokemonSeleccionado.name }}
            </h2>
            <div class="space-y-2">
            <p class="text-gray-700">
                <span class="font-semibold">Altura:</span>
                {{ pokemonSeleccionado.height / 10 }} metros
            </p>
            <p class="text-gray-700">
                <span class="font-semibold">Peso:</span>
                {{ pokemonSeleccionado.weight / 10 }} kg
            </p>
            </div>
        </div>
    </div>

        <p v-if="cargandoTipo" class="text-center mt-4">
        Cargando Pokemon...
        </p>
    </div>
</template>

<style scoped>

    button {
    transition: transform 0.2s ease;
    border-radius: 10px;
    }

    button:hover {
    transform: scale(1.05);
    }

    .cursor-pointer {
    cursor: pointer;
    }

    .fixed {
    z-index: 1000;
    }

    .fixed.inset-0 {
    background-color: rgba(0, 0, 0, 0.5);
    }

    .resultados-horizontal {
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    gap: 1rem;
    padding: 1rem 0;
    }

    .resultados-horizontal::-webkit-scrollbar {
    height: 8px;
    }

    .resultados-horizontal::-webkit-scrollbar-thumb {
    background-color: #a0aec0;
    border-radius: 4px;
    }

    .resultados-horizontal::-webkit-scrollbar-track {
    background-color: #e2e8f0;
    }

    .resultado_pokemon {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.8); /* Fondo oscuro semitransparente */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1000;
    padding: 1rem;
    }

    .resultado_pokemon img {
    width: 150px;
    height: auto;
    margin-bottom: 1rem;
    }

    .tarjeta-pokemon {
    flex: 0 0 auto;
    width: 150px;
    background-color: black;
    padding: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    text-align: center;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .tarjeta-pokemon:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 15px rgba(0, 0, 0, 0.2);
    }

    .text-center {
    text-align: center;
    }

    .text-gray-700 {
    color: #4a5568;
    }

    .font-bold {
    font-weight: 700;
    }

    .capitalize {
    text-transform: capitalize;
    }

    .max-w-sm {
    max-width: 24rem;
    }

    .w-full {
    width: 100%;
    }

    .mx-auto {
    margin-left: auto;
    margin-right: auto;
    }

    .p-6 {
    padding: 1.5rem;
    }

    .rounded-lg {
    border-radius: 0.5rem;
    }

    .text-gray-500 {
    color: #a0aec0;
    }

    .text-gray-500:hover {
    color: #718096;
    }

    .w-32 {
    width: 8rem;
    }

    .mt-4 {
    margin-top: 1rem;
    }
</style>