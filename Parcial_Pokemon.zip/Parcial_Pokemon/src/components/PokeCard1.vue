<script setup>
import { ref, computed } from 'vue';
import axios from 'axios';

// Almacena el nombre del Pokémon
const nombrepokemon = ref('');
// Almacena los datos del Pokémon encontrado
const pokemon = ref(null);
// Almacena el error
const error = ref('');
// Estado de carga
const cargando = ref(false);

const tipos = computed(() => {
    // Almacena los tipos del Pokémon
    return pokemon.value?.types?.map(t => t.type.name);
});

const buscarpokemon = async () => {
    error.value = '';
    pokemon.value = null;
    cargando.value = true;

    if (!nombrepokemon.value.trim()) {
        error.value = 'Por favor escribe el nombre o número del Pokémon';
        cargando.value = false;
        return;
    }

    try {
        // Convertir a minúsculas solo si no es un número
        const busqueda = isNaN(nombrepokemon.value)
            ? nombrepokemon.value.toLowerCase()
            : nombrepokemon.value;

        const res = await axios.get(`https://pokeapi.co/api/v2/pokemon/${busqueda}`);
        pokemon.value = res.data;
    } catch (e) {
        error.value = e.response?.status === 404
            ? 'Pokémon no encontrado'
            : 'Error al buscar Pokémon';
    } finally {
        cargando.value = false;
    }
};
</script>

<template>
    <div>
        <input
            type="text"
            v-model="nombrepokemon"
            placeholder="Ingrese el nombre del Pokémon"
            class="boder p-2 rounded-b-full"
        />
        <button
            @click="buscarpokemon"
            class="bg-blue-500 text-amber-50 px-4 py-2 rounded hover:bg-blue-500"
        >
            Buscar
        </button>
        <p v-if="cargando" class="text-blue-500 mt-4">Cargando...</p>
        <div v-if="pokemon" class="mt-6 bg-auto shadow-md rounded-b-full">
            <img :src="pokemon.sprites.front_default" alt="Imagen del Pokémon" />
            <h2>{{ pokemon.name }}</h2>
            <p>Altura: {{ pokemon.height }}</p>
            <p>Peso: {{ pokemon.weight }}</p>
            <p>Habilidades:</p>
            <ul>
                <p v-for="(move, index) in pokemon.moves.slice(0, 4)" :key="index">
                    {{ move.move.name }}
                </p>
            </ul>
            <p>
                Tipo:
                <span
                    v-for="tipo in tipos"
                    :key="tipo"
                    class="inline-block b-gray rounded"
                >
                    {{ tipo }}
                </span>
            </p>
        </div>
        <p v-if="error" class="text-red mt-4">{{ error }}</p>
    </div>
</template>

<style scoped>
    div {
    font-family: Arial, sans-serif;
    margin: 20px auto;
    max-width: 500px;
    text-align: center;
    }

    input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 2px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    }

    button {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    }

    button:hover {
    background-color: #0056b3;
    }

    div.v-if {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    img {
    max-width: 150px;
    margin: 0 auto;
    display: block;
    border-radius: 50%;
    background-color: #f1f1f1;
    padding: 10px;
    }

    img:hover {
    transform: scale(1.2);
    transition: transform 0.3s;
    }

    h2 {
    font-size: 24px;
    color: lightyellow;
    margin: 10px 0;
    }

    p {
    font-size: 16px;
    color: lightyellow;
    margin: 5px 0;
    }

    ul {
    list-style: none;
    padding: 0;
    }

    ul p {
    background-color: #e3f2fd;
    color: #007BFF;
    padding: 5px 10px;
    border-radius: 8px;
    display: inline-block;
    margin: 5px;
    }

    ul p:hover {
    transform: scale(1.1);
    transition: transform 0.3s;
    }

    span {
    background-color: #d1c4e9;
    color: #5e35b1;
    padding: 5px 10px;
    border-radius: 8px;
    margin: 5px;
    display: inline-block;
    }

    span:hover {
    transform: scale(1.1);
    transition: transform 0.3s;
    }

    .text-red {
    color: #e53935;
    font-weight: bold;
    margin-top: 10px;
    }
</style>