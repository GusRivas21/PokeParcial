<script setup>
import PokeCard1 from './components/PokeCard1.vue';
import PokeCard2 from './components/PokeCard2.vue';

</script>

<template>

    <PokeCard1/>
    <PokeCard2/>

</template>

<style scoped>

</style>
